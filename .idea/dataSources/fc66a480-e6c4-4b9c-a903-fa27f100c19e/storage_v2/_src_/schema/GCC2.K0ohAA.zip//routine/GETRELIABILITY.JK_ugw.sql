create Function getReliability(examid in varchar2) return number as
  minnum       number;
  avgscoreX    number; --X: odd
  avgscoreY    number; --Y: even
  stddevscoreX number;
  stddevscoreY number;
  reliability  number;

begin

  select floor(count(se.count) / 2)
    into minnum
    from student_exam se
   where se.count is not null
     and se.eid = examid;

  select avg(s.count), stddev(s.count)
    into avgscoreX, stddevscoreX
    from (select res.count, rownum as rn
            from (select t.count
                    from student_exam t
                   where t.eid = examid
                     and t.count is not null
                   order by t.snum) res) s
   where MOD(s.rn, 2) != 0;

  select avg(s.count), stddev(s.count)
    into avgscoreY, stddevscoreY
    from (select res.count, rownum as rn
            from (select t.count
                    from student_exam t
                   where t.eid = examid
                     and t.count is not null
                   order by t.snum) res) s
   where MOD(s.rn, 2) = 0;

if minnum * stddevscoreX * stddevscoreY!=0 then
  select round(sum(e.score) / (minnum * stddevscoreX * stddevscoreY), 4)
  --select round(sum(e.score), 4)
    into reliability
    from (select (e1.count - avgscoreX) * (e2.count - avgscoreY) as score
            from (select s.count, rownum as rn
                    from (select res.count, rownum as rn
                            from (select t.count
                                    from student_exam t
                                   where t.eid = examid
                                     and t.count is not null
                                   order by t.snum) res) s
                   where MOD(s.rn, 2) != 0) e1,
                 (select s.count, rownum as rn
                    from (select res.count, rownum as rn
                            from (select t.count
                                    from student_exam t
                                   where t.eid = examid
                                     and t.count is not null
                                   order by t.snum) res) s
                   where MOD(s.rn, 2) = 0) e2
           where e1.rn = e2.rn) e;
else reliability:=0;
end if;
  return reliability;
end;


/

