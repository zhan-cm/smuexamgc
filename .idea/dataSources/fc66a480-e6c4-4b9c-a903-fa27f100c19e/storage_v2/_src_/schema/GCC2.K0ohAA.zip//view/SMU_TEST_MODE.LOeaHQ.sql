create view SMU_TEST_MODE as
select "ID","NAME"
    from kaoyi.test_mode


/

