create trigger ADDR_ORDER
    before insert
    on ADDR4EXAM
    for each row
    when (new.aorder is null)
begin
select ADDR_SEQ.nextval into:new.aorder from dual;
end;



/

