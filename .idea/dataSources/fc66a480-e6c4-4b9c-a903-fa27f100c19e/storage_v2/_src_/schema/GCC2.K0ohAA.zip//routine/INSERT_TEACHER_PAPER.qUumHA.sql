create Procedure       insert_teacher_paper as
begin
  for cr in (select t.id from kslx0 t where t.kslxxh = 17) loop
    insert into teacher_paper
      (tid, eid, pid)
      select te.id, ei.id, res.rn - 1
        from teacher te,
             (select trim(substr(text,
                                 instr(text, ',', 1, rn) + 1,
                                 instr(text, ',', 1, rn + 1) -
                                 instr(text, ',', 1, rn) - 1)) pgst,
                     saname,
                     rn,
                     id2
                from (select ',' || t1.pgst || ',' text,
                             t2.rn,
                             t1.saname,
                             t1.id2
                        from KSLX0 t1,
                             (select rownum rn
                                from all_objects
                               where rownum <=
                                     (select length(t.pgst) -
                                             length(replace(t.pgst, ',', ''))
                                        from KSLX0 t
                                       where t.id = cr.id)) t2
                       where t1.id = cr.id)) res
       inner join examinfo ei
          on ei.num = res.id2
       where pgst like 'checked'
         and res.saname = te.name;
  end loop;
end;


/

