create Procedure       insert_course_specialty as
begin
  for cr in (select t.id from TRYINFO0 t) loop
    insert into course_specialty
      (cid, spid, spname, sporder)
      (select res.id, s.id, res.text, s.sorder
         from (select trim(substr(text,
                                  instr(text, ',', 1, rn) + 1,
                                  instr(text, ',', 1, rn + 1) -
                                  instr(text, ',', 1, rn) - 1)) text,
                      t3.id
                 from (select ',' || t1.syzy || ',' text, t2.rn
                         from TRYINFO0 t1,
                              (select rownum rn
                                 from all_objects
                                where rownum <=
                                      (select length(t.syzy) -
                                              length(replace(t.syzy, ',', '')) + 1
                                         from TRYINFO0 t
                                        where t.id = cr.id)) t2

                        where t1.id = cr.id),
                      TRYINFO0 t3
                where t3.id = cr.id) res
         left join specialty s
           on res.text = s.name
          and s.state = 1);
  end loop;
end;


/

