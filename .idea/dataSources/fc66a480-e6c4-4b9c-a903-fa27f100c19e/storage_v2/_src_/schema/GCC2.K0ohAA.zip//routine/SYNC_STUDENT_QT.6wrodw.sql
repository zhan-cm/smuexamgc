create procedure sync_student_qt as
begin
  for s in(select distinct sid from student_answer_question_exam where eid='9768') loop
    insert into student_answer_qtype_exam(eid,qtid,sid,qtorder,isfinish,isexist) values('9768','155',s.sid,5,0,0);
 end loop;    
end sync_student_qt;


/

