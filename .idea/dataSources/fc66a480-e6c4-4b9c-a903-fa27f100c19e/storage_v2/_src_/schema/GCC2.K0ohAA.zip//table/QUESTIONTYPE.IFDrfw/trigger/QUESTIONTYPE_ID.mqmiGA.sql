create trigger QUESTIONTYPE_ID
    before insert
    on QUESTIONTYPE
    for each row
    when (NEW.ID IS NULL)
BEGIN
  SELECT qt01_SEQ.NEXTVAL INTO :NEW.ID FROM dual;
END;


/

