create view SMU_THEME as
select "ID","NAME","PID","TLEVEL","CID","STATE"
    from kaoyi.theme


/

