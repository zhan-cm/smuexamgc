create Function getDSByCognition(examid in varchar2,
                                            coid   in varchar2)
  return number as
  discrimination number;

begin

  select round((res1.a - res2.a) / res1.score, 4)
    into discrimination
    from (select avg(t1.count) as a,
                 min(t1.eid) as eid,
                 max(t1.score) as score
            from (select t.eid,
                         t.count,
                         t.score,
                         percent_rank() over(order by t.count) as pr
                    from (select sum(sa.averagescore) as count,
                                 min(sa.eid) as eid,
                                 sum(eq.score) as score
                            from student_answer     sa,
                                 exampaper_question_db eq
                           where sa.qid = eq.qid
                             and eq.eid = examid
                             and sa.eid = examid
                             and eq.cognitionid_bachelor=coid
                           group by sa.sid) t) t1
           where t1.pr >= 0.73) res1,
         (select avg(t1.count) as a, min(t1.eid) as eid
            from (select t.eid,
                         t.count,
                         percent_rank() over(order by t.count) as pr
                    from (select sum(sa.averagescore) as count,
                                 min(sa.eid) as eid
                            from student_answer     sa,
                                 exampaper_question_db eq
                           where sa.qid = eq.qid
                             and eq.eid = examid
                             and sa.eid = examid
                             and eq.cognitionid_bachelor = coid
                           group by sa.sid) t) t1
           where t1.pr <= 0.27) res2
   where res1.eid = res2.eid
     and res1.eid = examid;

  return discrimination;

end;


/

