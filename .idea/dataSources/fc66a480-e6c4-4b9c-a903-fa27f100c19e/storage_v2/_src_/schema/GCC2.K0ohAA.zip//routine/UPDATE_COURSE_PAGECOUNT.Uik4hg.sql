create PROCEDURE UPDATE_COURSE_PAGECOUNT(cidin in varchar2) as
  pCount number := 0;
  pCount2 number:=0;
begin
    select count(cid)
      into pCount
      from course_ques_page_total
     where cid = cidin;
    select count(p.id)
      into pCount2
      from examinfo p,exampaper_course ec2
     where p.state != -1
     and p.id=ec2.eid
       and ec2.cid = cidin;
    if (pCount = 0) then
      begin
        insert into course_ques_page_total
          (id, cid, page_total)
          select ctotal001_seq.nextval, cidin, pCount2 from dual;
        commit;
      end;
    else
      begin
        update course_ques_page_total
           set page_total = pCount2
         where cid = cidin;
        commit;
     end;
    end if;
end;


/

