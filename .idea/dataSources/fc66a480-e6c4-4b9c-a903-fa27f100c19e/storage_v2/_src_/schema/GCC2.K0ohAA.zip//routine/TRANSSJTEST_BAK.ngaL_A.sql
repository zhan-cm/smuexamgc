create procedure transSjtest_bak as
  time number;
begin
  for sj in (select * from sjtest where eid='305') loop
    for qids in (select q.id,
                        q.version,
                        qv.qtid,
                        qv.answerid,
                        q.ismain,
                        q.qtiscon,
                        q.mqid
                   from question_version qv, question q
                  where qv.qid = q.id
                    and q.cid = sj.kcid
                    and q.qid = sj.id) loop
      select max(t.id)
        into time
        from system_time t
       where t.name <= sj.ydsj0 * 60;
      if (time is null) then
        time := 3;
      end if;
      insert into exampaper_question_bak
        (EID,
         QID,
         VERSION,
         QORDER,
         TIME,
         SCORE,
         QTYPE,
         ANSWERID,
         MAIN,
         QTISCON,
         MQID,
         CID,
         ID3)
      values
        (sj.eid, qids.id, 0, sj.tmsx, time, sj.fz, qids.qtid, qids.answerid, qids.ismain, qids.qtiscon, qids.mqid, sj.kcid, sj.id3);
    end loop;
  end loop;
end transSjtest;


/

