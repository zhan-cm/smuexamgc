create view SMU_SCHOOLYEAR as
select "ID","NAME"
    from kaoyi.schoolyear


/

