create Procedure       insert_course_arrangement as
begin
  for cr in (select t.id from TRYINFO0 t) loop
    insert into course_arrangement
      (cid, aid, aname, aorder)
      (select res.id,
              decode(trim(res.text),
                     '成人专科',
                     1,
                     '专科',
                     2,
                     '专升本',
                     3,
                     '本科生',
                     4,
                     '硕士研究生',
                     5,
                     '博士研究生',
                     6,
                     '成人本科',
                     7) as aid,
              trim(res.text),
              decode(trim(res.text),
                     '成人专科',
                     1,
                     '专科',
                     2,
                     '专升本',
                     3,
                     '本科生',
                     4,
                     '硕士研究生',
                     5,
                     '博士研究生',
                     6,
                     '成人本科',
                     7) as aorder
         from (select substr(text,
                             instr(text, ',', 1, rn) + 1,
                             instr(text, ',', 1, rn + 1) -
                             instr(text, ',', 1, rn) - 1) text,
                      t3.id
                 from (select ',' || t1.sycc || ',' text, t2.rn
                         from TRYINFO0 t1,
                              (select rownum rn
                                 from all_objects
                                where rownum <=
                                      (select length(t.sycc) -
                                              length(replace(t.sycc, ',', '')) + 1
                                         from TRYINFO0 t
                                        where t.id = cr.id)) t2

                        where t1.id = cr.id),
                      TRYINFO0 t3
                where t3.id = cr.id) res);
  end loop;
end;


/

