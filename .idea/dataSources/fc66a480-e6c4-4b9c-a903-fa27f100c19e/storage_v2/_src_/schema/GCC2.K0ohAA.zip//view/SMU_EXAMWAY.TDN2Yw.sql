create view SMU_EXAMWAY as
select "ID","NAME"
    from kaoyi.examway


/

