create trigger NEWSTB_ID
    before insert
    on NEWSTB
    for each row
    when (new.id is null)
begin
select NEWS_SEQ.nextval into:new.id from dual;
end;


/

