create Procedure       updateRank(examID in varchar2) as
begin
  for cr in (select a.sid as sid,
                    a.eid as eid,
                    rank() over(partition by a.eid order by a.score desc nulls last) as ranking,
                    a.score as score
               from (select sa.sid, sa.eid, sum(sa.averagescore) as score
                       from student_answer sa
                      group by sa.eid, sa.sid) a
              where a.eid = examID) loop
    update student_exam se
       set se.ranking = cr.ranking, se.count = cr.score
     where se.eid = cr.eid
       and se.sid = cr.sid;
  end loop;
  update examinfo t set t.state = 6 where t.id = examID;
end;


/

