create Procedure       insert_question_answer as
begin
  for cr in (select qv.qid, qt.answertypeid as atid, qv.answer as a
               from question q, question_version qv
               inner join questiontype qt
                 on qv.qtid = qt.id
              where q.id = qv.qid
                and q.ismain = 0
                and q.cid != '1004863'
                and q.version = qv.version) loop
    if cr.atid = 0 or cr.atid = 1 or cr.atid = 2 or cr.atid = 3 then
      insert into answer
        (id, content, qid, qversion, atid)
        (select 0, 'A', cr.qid, 0, cr.atid from dual) union
        (select 1, 'B', cr.qid, 0, cr.atid from dual) union
        (select 2, 'C', cr.qid, 0, cr.atid from dual) union
        (select 3, 'D', cr.qid, 0, cr.atid from dual) union
        (select 4, 'E', cr.qid, 0, cr.atid from dual);
    else
      if cr.atid = 4 and trim(cr.a) = '对' then
        insert into answer
          (id, content, qid, qversion, atid)
          (select 0, 'true', cr.qid, 0, cr.atid from dual);
      else
        if cr.atid = 4 and trim(cr.a) = '错' then
          insert into answer
            (id, content, qid, qversion, atid)
            (select 1, 'false', cr.qid, 0, cr.atid from dual);
        else
          insert into answer
            (id, content, qid, qversion, atid)
            (select 0, cr.a, cr.qid, 0, cr.atid from dual);
        end if;
      end if;
    end if;
  end loop;
end;


/

