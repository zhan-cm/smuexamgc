create view SMU_KNOWLEDGE as
select "ID","NAME"
    from kaoyi.knowledge


/

