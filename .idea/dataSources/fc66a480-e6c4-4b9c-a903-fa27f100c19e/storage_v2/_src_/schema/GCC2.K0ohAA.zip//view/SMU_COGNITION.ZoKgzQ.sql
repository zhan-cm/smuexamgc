create view SMU_COGNITION as
select "ID","NAME"
    from kaoyi.cognition


/

