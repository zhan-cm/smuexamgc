create Function getDiscrimination(examid in varchar2)
  return number as
  discrimination number;

begin

  select round((res1.a - res2.a) / ei.score, 4)
    into discrimination
    from (select avg(t1.count) as a, min(t1.eid) as eid
            from (select t.eid,
                         t.count,
                         percent_rank() over(order by t.count) as pr
                    from STUDENT_EXAM t
                   where t.count is not null
                     and t.eid = examid) t1
           where t1.pr >= 0.73) res1,
         (select avg(t1.count) as a, min(t1.eid) as eid
            from (select t.eid,
                         t.count,
                         percent_rank() over(order by t.count) as pr
                    from STUDENT_EXAM t
                   where t.count is not null
                     and t.eid = examid) t1
           where t1.pr <= 0.27) res2,
         examinfo ei
   where res1.eid = res2.eid
     and res1.eid = ei.id
     and ei.id = examid;

  return discrimination;

end;


/

