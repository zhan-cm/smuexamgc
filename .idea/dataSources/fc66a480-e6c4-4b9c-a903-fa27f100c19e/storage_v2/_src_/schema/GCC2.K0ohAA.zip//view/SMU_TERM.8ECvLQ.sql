create view SMU_TERM as
select "ID","NAME"
    from kaoyi.term


/

