create Procedure       insert_teacher_permission as
begin
  for cr in (select t.id from qxb0 t) loop
    insert into teacher_permission
      (tid, cid, pid)
      select te.id, res.kcid, res.rn
        from (select trim(substr(text,
                                 instr(text, ',', 1, rn) + 1,
                                 instr(text, ',', 1, rn + 1) -
                                 instr(text, ',', 1, rn) - 1)) qx,
                     saname,
                     rn,
                     kcid
                from (select ',' || t1.qx || ',' text,
                             t2.rn,
                             t1.saname,
                             t1.kcid
                        from QXB0 t1,
                             (select rownum rn
                                from all_objects
                               where rownum <=
                                     (select length(t.qx) -
                                             length(replace(t.qx, ',', ''))
                                        from QXB0 t
                                       where t.id = cr.id)) t2
                       where t1.id = cr.id)) res,
             teacher te
       where qx like 'checked'
         and res.saname = te.name;
  end loop;
end;


/

