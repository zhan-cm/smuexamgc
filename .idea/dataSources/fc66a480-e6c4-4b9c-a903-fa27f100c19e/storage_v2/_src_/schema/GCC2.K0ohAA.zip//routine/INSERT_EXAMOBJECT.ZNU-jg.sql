create Procedure       insert_examobject as
begin
  for cr in (select t.id from examinfo0 t, examinfo ei where t.id = ei.num) loop
    insert into examobject
      (eid, grade, specialtyid)
      select ei.id, res.rxnj, s.id
        from examinfo ei,
             specialty s,
             (select trim(substr(text,
                                 instr(text, ',', 1, rn) + 1,
                                 instr(text, ',', 1, rn + 1) -
                                 instr(text, ',', 1, rn) - 1)) ksdx,
                     id,
                     rxnj
                from (select ',' || t1.ksdx || ',' text,
                             t1.id as id,
                             t2.rn,
                             t1.rxnj
                        from examinfo0 t1,
                             (select rownum rn
                                from all_objects
                               where rownum <=
                                     (select length(t.ksdx) -
                                             length(replace(t.ksdx, ',', ''))
                                        from examinfo0 t
                                       where t.id = cr.id)) t2
                       where t1.id = cr.id)) res
       where res.ksdx = s.name
         and ei.num = res.id;
  end loop;
end;


/

