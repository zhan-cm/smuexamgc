create view SMU_COURSE as
select "ID","NAME_C","NAME_E","SHORTNAME","CODE","UNITID","DEPTID","PERIOD","CREATORID","STATE","OPEN"
    from kaoyi.course


/

