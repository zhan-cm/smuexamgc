create trigger TEMPLATE_ID
    before insert
    on TEMPLATE
    for each row
    when (new.id is null)
begin select tp01_seq.nextval into:new.id from dual;
  end;




/

