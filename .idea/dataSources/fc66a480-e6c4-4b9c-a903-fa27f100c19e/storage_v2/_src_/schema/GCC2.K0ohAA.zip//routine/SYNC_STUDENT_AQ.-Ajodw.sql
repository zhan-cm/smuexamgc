create procedure sync_student_aq as
begin
  for s in(select distinct sid from student_answer_question_exam  where eid='9768') loop
    insert into student_answer_question_exam(eid,qid,qtid,sid,qorder,qtorder,isfinish,isexist) values('9768','476210','155',s.sid,0,5,0,0);
    insert into student_answer_question_exam(eid,qid,qtid,sid,qorder,qtorder,isfinish,isexist) values('9768','476212','155',s.sid,1,5,0,0);
    insert into student_answer_question_exam(eid,qid,qtid,sid,qorder,qtorder,isfinish,isexist) values('9768','476214','155',s.sid,2,5,0,0);
    insert into student_answer_question_exam(eid,qid,qtid,sid,qorder,qtorder,isfinish,isexist) values('9768','477608','155',s.sid,3,5,0,0);
    insert into student_answer_question_exam(eid,qid,qtid,sid,qorder,qtorder,isfinish,isexist) values('9768','478805','155',s.sid,4,5,0,0);
    insert into student_answer_question_exam(eid,qid,qtid,sid,qorder,qtorder,isfinish,isexist) values('9768','478807','155',s.sid,5,5,0,0);
    insert into student_answer_question_exam(eid,qid,qtid,sid,qorder,qtorder,isfinish,isexist) values('9768','55376','155',s.sid,6,5,0,0);
    insert into student_answer_question_exam(eid,qid,qtid,sid,qorder,qtorder,isfinish,isexist) values('9768','55374','155',s.sid,7,5,0,0);
 end loop;
end sync_student_aq;


/

