create trigger THEME_ORDER
    before insert
    on THEME
    for each row
    when (new.torder is null)
begin
select TH02_SEQ.nextval into:new.torder from dual;
end;




/

