create Procedure       insert_course_difficulty as
begin
  for cr in (select t.id from TRYINFO0 t) loop
    insert into course_difficulty
      (cid, did, dname, dorder)
      (select res.id, d.id, res.text, d.dorder
         from (select trim(substr(text,
                                  instr(text, ',', 1, rn) + 1,
                                  instr(text, ',', 1, rn + 1) -
                                  instr(text, ',', 1, rn) - 1)) text,
                      t3.id
                 from (select ',' || t1.ndlx || ',' text, t2.rn
                         from TRYINFO0 t1,
                              (select rownum rn
                                 from all_objects
                                where rownum <=
                                      (select length(t.ndlx) -
                                              length(replace(t.ndlx, ',', '')) + 1
                                         from TRYINFO0 t
                                        where t.id = cr.id)) t2

                        where t1.id = cr.id),
                      TRYINFO0 t3
                where t3.id = cr.id) res
         left join difficulty d
           on res.text = d.name);
  end loop;
end;


/

