create Procedure       insert_question_answerid as
begin
  for cr in (select qv.qid, qt.answertypeid as atid, qv.answer as a
               from question q, question_version qv
               inner join questiontype qt
                 on qv.qtid = qt.id
              where q.id = qv.qid
                and q.ismain = 0
                and q.qid is not null
                and q.cid != '1004863'
                and q.version = qv.version) loop
    if cr.atid = 0 then
      update question_version
         set answerid =
             (select replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(res.aid,
                                                                                       'A',
                                                                                       '0'),
                                                                               'B',
                                                                               '1'),
                                                                       'C',
                                                                       '2'),
                                                               'D',
                                                               '3'),
                                                       'E',
                                                       '4'),
                                               'Ａ',
                                               '0'),
                                       'Ｂ',
                                       '1'),
                               'Ｃ',
                               '2'),
                       'Ｄ',
                       '3'),
               'Ｅ',
               '4')
                from (select case
                               when instr(trim(cr.a), 'br') > 0 then
                                substr(trim(cr.a), 0, 1)
                               when instr(trim(cr.a), 'P') > 0 then
                                substr(trim(cr.a), 4, 1)
                               else
                                trim(cr.a)
                             end as aid
                        from question_version qv
                       where qv.qid = cr.qid
                         and qv.version = 0) res)
       where qid = cr.qid;
    else
      if cr.atid = 1 then
        update question_version
           set answerid = replace(replace(replace(replace(replace(replace(replace(replace(replace(replace(cr.a,
                                                                                       'A',
                                                                                       '0'),
                                                                               'B',
                                                                               '1'),
                                                                       'C',
                                                                       '2'),
                                                               'D',
                                                               '3'),
                                                       'E',
                                                       '4'),
                                               'Ａ',
                                               '0'),
                                       'Ｂ',
                                       '1'),
                               'Ｃ',
                               '2'),
                       'Ｄ',
                       '3'),
               'Ｅ',
               '4')
         where qid = cr.qid;
      else
        if cr.atid = 4 and trim(cr.a) = '对' then
          update question_version set answerid = 0 where qid = cr.qid;
        else
          if cr.atid = 4 and trim(cr.a) = '错' then
            update question_version set answerid = 1 where qid = cr.qid;
          else
            update question_version set answerid = 0 where qid = cr.qid;
          end if;
        end if;
      end if;
    end if;
  end loop;
end;


/

