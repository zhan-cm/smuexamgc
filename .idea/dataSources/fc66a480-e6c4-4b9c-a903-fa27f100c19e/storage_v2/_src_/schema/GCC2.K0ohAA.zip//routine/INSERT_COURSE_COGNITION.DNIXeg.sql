create Procedure       insert_course_cognition as
begin
  for cr in (select t.id from TRYINFO0 t) loop
    insert into course_cognition
      (cid, coid, coname, coorder)
      (select res.id, co.id, res.text, co.coorder
         from (select trim(substr(text,
                                  instr(text, ',', 1, rn) + 1,
                                  instr(text, ',', 1, rn + 1) -
                                  instr(text, ',', 1, rn) - 1)) text,
                      t3.id
                 from (select ',' || t1.rzlx || ',' text, t2.rn
                         from TRYINFO0 t1,
                              (select rownum rn
                                 from all_objects
                                where rownum <=
                                      (select length(t.rzlx) -
                                              length(replace(t.rzlx, ',', '')) + 1
                                         from TRYINFO0 t
                                        where t.id = cr.id)) t2

                        where t1.id = cr.id),
                      TRYINFO0 t3
                where t3.id = cr.id) res
         left join cognition co
           on res.text = co.name);
  end loop;
end;


/

