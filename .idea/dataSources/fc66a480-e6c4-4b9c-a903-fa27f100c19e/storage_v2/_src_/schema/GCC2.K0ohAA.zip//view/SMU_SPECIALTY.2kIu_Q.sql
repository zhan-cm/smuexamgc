create view SMU_SPECIALTY as
select "ID","NAME","UNITID","STATE"
    from kaoyi.specialty


/

