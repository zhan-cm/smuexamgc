create trigger QUESTIONTYPE_ORDER
    before insert
    on QUESTIONTYPE
    for each row
    when (NEW.QORDER IS NULL)
BEGIN
  SELECT qt02_SEQ.NEXTVAL INTO :NEW.QORDER FROM dual;
END;


/

