create trigger EXAMINFO_ID
    before insert
    on EXAMINFO
    for each row
    when (new.ID is null)
begin
select EI01_SEQ.nextval into:new.ID from dual;
end;




/

