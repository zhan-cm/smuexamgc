create trigger THEME_ID
    before insert
    on THEME
    for each row
    when (new.id is null)
begin
select TH01_SEQ.nextval into:new.id from dual;
end;




/

