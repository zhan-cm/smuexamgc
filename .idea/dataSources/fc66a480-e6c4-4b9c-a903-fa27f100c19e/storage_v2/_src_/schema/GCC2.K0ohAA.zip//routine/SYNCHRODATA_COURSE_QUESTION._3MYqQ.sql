create PROCEDURE "SYNCHRODATA_COURSE_QUESTION" as
  qCount number := 0;
  qCount2 number:=0;
  cid    nvarchar2(50);
begin
  for cr in (select distinct (cid) as cid from question_db) loop
    select count(cid)
      into qCount
      from course_ques_page_total
     where cid = cr.cid;
     select count(cid) into qCount2
                  from question_db q
                 where q.ismain=0 and q.state != '2'
                   and cid = cr.cid;
    if (qCount = 0) then
    begin
      insert into course_ques_page_total
        (id, cid, question_total)
        select ctotal001_seq.nextval, cr.cid, qCount2
          from dual;
     commit;
     end;
     else 
     begin
        update course_ques_page_total set question_total=qCount2 where cid=cr.cid;
        commit;
        end;
    end if;
  end loop;
end;


/

