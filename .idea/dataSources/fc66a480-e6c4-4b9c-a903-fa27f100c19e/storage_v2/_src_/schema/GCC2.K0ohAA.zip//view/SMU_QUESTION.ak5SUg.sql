create view SMU_QUESTION as
select "ID","CID","CNAME","STATE"
    from kaoyi.question


/

