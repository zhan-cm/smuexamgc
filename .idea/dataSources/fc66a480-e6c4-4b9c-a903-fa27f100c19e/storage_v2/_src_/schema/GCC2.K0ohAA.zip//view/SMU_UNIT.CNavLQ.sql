create view SMU_UNIT as
select "ID","NAME","STATE"
    from kaoyi.unit


/

