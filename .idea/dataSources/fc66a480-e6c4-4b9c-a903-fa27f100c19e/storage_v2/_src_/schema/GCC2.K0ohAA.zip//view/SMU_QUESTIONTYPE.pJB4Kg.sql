create view SMU_QUESTIONTYPE as
select "ID","NAME","QDESC","ISCON","ANSWERTYPEID","ANSWERTYPE"
    from kaoyi.questiontype


/

