create procedure synStudent is
  sid varchar2(100);
  s_num varchar2(100);
  s_name varchar2(100);
  g_name varchar2(100);
  spe_name varchar2(100);
  s_class varchar2(100);
  s_tel varchar2(100);

  speid varchar2(100);
  unitid varchar2(100);
  gradeid NUMBER;

  recordnum number;
  recordnum_spe number;
  recordnum_unit number;
  recordnum_grade number;

begin
  for jw in (select * from student_jw) loop

  sid:='';
  s_num:='';
  s_name:='';
  g_name:='';
  s_class:='';
  s_tel:='';
  speid:='';
  unitid:='';
  gradeid:=0;

  select count(*) into recordnum_unit from unit where name=jw.yxmc;
  if recordnum_unit=0 then
    select U01_SEQ.nextval into unitid from dual;
    insert into unit(id,name,uorder) values(unitid,jw.yxmc,unitid);
  else
    select id into unitid from unit where name=jw.yxmc;
  end if;

  select count(*) into recordnum_spe from specialty where name=jw.zymc and unitid=unitid;
  if recordnum_spe=0 then
    select sp01_SEQ.nextval into speid from dual;
    insert into specialty(id,name,unitid,sorder) values(speid,jw.zymc,unitid,speid);
   else
     select id into speid from specialty where name=jw.zymc and unitid=unitid and rownum=1;
   end if;

   select count(*) into recordnum_grade from grade where name=jw.dqszj||'级';
   if recordnum_grade=0 then
     select max(to_number(id))+1 into gradeid from grade;
     insert into grade(id,name) values (gradeid,jw.dqszj||'级');
   else
      select id into gradeid from grade where name=jw.dqszj||'级';
   end if;

  select count(*) into recordnum from student_bak s where s.num=jw.xsbh;
  if recordnum=0 then
     select stu01_seq.nextval into sid from dual;
     insert into student_bak(id,name,class,specialtyid,specialty,grade,tel,num) values(sid,jw.xsxm,jw.bjmc,speid,jw.zymc,gradeid,jw.dh,s_num);

  else
    select s.num,s.name,g.name,spe.name,s.class,s.tel into s_num,s_name,g_name,spe_name,s_class,s_tel from student_bak s
left join specialty spe on spe.id=s.specialtyid
left join grade g on g.id=s.grade
where s.num=jw.xsbh;
   update student_bak set name=jw.xsxm,class=jw.bjmc,specialtyid=speid,specialty=jw.zymc,grade=gradeid,tel=jw.dh where num=s_num;

end if;

end loop;
end synStudent;


/

