create procedure updateExaminfoCids as
  cids nvarchar2(4000);
begin
  for sj in (select id from examinfo where cid='0') loop
    cids:='';
    for qids in (select ec.cid from exampaper_course ec where ec.eid=sj.id) loop
      cids:=cids||','||qids.cid;
    end loop;
    cids:=substr(cids,2,length(cids));
    update examinfo ei set ei.cid=cids where ei.id=sj.id;
  end loop;
end updateExaminfoCids;


/

