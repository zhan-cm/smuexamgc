create view SMU_ARRANGEMENT as
select "ID","NAME"
    from kaoyi.arrangement


/

