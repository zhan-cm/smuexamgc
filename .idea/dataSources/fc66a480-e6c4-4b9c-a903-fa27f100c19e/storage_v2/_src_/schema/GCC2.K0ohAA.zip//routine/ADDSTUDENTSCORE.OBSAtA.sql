create procedure addStudentScore(v_eid varchar)
       is
       cursor a_cursor is
              select s.id from student_exam_exam se,student s where se.eid = v_eid and se.sid = s.id and s.specialtyid !=0;
       cursor b_cursor(v_sid varchar2) is
              select qid,qtid,answerid,score from exampaper_question_db eq where eq.qid not in (select qid from student_answer_question_exam saq where saq.eid = v_eid and saq.sid = v_sid) and eq.eid = v_eid;
begin
  for a_cur in a_cursor loop
    for b_cur in b_cursor (a_cur.id) loop
      insert into student_answer_question_exam (eid,qid,qtid,sid,qorder,qtorder,isfinish,isexist) values (v_eid,b_cur.qid,b_cur.qtid,a_cur.id,0,2,1,0);
      insert into student_answer_exam (eid, qid, aid, sid, qtid, score, averagescore, answertime, answertdate, atid, ismain) values (v_eid, b_cur.qid, b_cur.answerid, a_cur.id, b_cur.qtid, b_cur.score, b_cur.score, 20, (select sysdate from dual), 0, 0);
      end loop;
end loop;
end addStudentScore;


/

