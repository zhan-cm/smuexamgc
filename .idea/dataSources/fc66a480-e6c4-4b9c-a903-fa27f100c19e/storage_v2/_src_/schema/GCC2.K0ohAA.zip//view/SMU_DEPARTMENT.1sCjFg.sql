create view SMU_DEPARTMENT as
select "ID","NAME","UNITID","UNAME","STATE"
    from kaoyi.department


/

