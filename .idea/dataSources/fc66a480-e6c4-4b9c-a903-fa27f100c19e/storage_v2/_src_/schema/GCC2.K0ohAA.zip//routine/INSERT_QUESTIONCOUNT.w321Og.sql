create Procedure       insert_questionCount as
  v_query VARCHAR2(200);
begin
  for cr in (select t.id from TRYINFO0 t) loop
    v_query := 'insert into QC (id, qcount) (select '||cr.id||', count(1) from STK' || cr.id || '0 t)';
    EXECUTE IMMEDIATE v_query;
  end loop;
end;


/

