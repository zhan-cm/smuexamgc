create view SMU_ANSWERTYPE as
select "ID","NAME"
    from kaoyi.answertype


/

