create view SMU_STUDENT_JW as
select "XSBH","XSXM","DQSZJ","ZYMC","BJMC","YXMC"
    from kaoyi.student_jw


/

