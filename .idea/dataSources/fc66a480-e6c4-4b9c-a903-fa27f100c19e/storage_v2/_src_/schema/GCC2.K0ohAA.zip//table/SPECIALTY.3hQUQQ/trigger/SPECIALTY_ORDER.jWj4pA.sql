create trigger SPECIALTY_ORDER
    before insert
    on SPECIALTY
    for each row
    when (new.sorder is null)
begin
select sp02_SEQ.nextval into:new.sorder from dual;
end;

/

