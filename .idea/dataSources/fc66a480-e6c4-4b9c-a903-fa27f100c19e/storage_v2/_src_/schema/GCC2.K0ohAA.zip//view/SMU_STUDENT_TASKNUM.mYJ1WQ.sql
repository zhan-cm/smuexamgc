create view SMU_STUDENT_TASKNUM as
select "ID","TASK_NUM","NUM","SCORE","NAME","KSRQ","SJBH","KCMC"
    from kaoyi.student_tasknum


/

