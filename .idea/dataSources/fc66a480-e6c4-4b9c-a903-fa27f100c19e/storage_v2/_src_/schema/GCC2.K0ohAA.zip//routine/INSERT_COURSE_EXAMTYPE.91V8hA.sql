create Procedure       insert_course_examtype as
begin
  for cr in (select t.id from TRYINFO0 t) loop
    insert into course_examtype
      (cid, etid, etname, etorder)
      (select res.id, et.id, res.text, et.eorder
         from (select trim(substr(text,
                                  instr(text, ',', 1, rn) + 1,
                                  instr(text, ',', 1, rn + 1) -
                                  instr(text, ',', 1, rn) - 1)) text,
                      t3.id
                 from (select ',' || t1.kslx || ',' text, t2.rn
                         from TRYINFO0 t1,
                              (select rownum rn
                                 from all_objects
                                where rownum <=
                                      (select length(t.kslx) -
                                              length(replace(t.kslx, ',', '')) + 1
                                         from TRYINFO0 t
                                        where t.id = cr.id)) t2

                        where t1.id = cr.id),
                      TRYINFO0 t3
                where t3.id = cr.id) res
         left join examtype et
           on res.text = et.name);
  end loop;
end;


/

