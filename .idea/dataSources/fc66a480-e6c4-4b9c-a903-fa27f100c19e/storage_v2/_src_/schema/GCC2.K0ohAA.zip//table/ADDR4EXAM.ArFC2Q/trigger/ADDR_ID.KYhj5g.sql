create trigger ADDR_ID
    before insert
    on ADDR4EXAM
    for each row
    when (new.id is null)
begin
select ADDRID_SEQ.nextval into:new.id from dual;
end;



/

