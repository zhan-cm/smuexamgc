create view VIEW_OFFLINE_ACHIEVEMENT as
SELECT
    eid,
    snum,
    sname,
    specialty,
    grade,
    CLASS,
    LISTAGG(qtname, ',') WITHIN GROUP (ORDER BY qtname) AS qtname,
    LISTAGG(score, ',') WITHIN GROUP (ORDER BY qtname) AS score
FROM
    offline_achievement
GROUP BY
    eid,
    snum,
    sname,
    specialty,
    grade,
    CLASS
ORDER BY
    qtname
/

