create Procedure       insert_course_knowledge as
begin
  for cr in (select t.id from TRYINFO0 t) loop
    insert into course_knowledge
      (cid, kid, kname, korder)
      (select res.id, k.id, res.text, k.korder
         from (select trim(substr(text,
                                  instr(text, ',', 1, rn) + 1,
                                  instr(text, ',', 1, rn + 1) -
                                  instr(text, ',', 1, rn) - 1)) text,
                      t3.id
                 from (select ',' || t1.yqdlx || ',' text, t2.rn
                         from TRYINFO0 t1,
                              (select rownum rn
                                 from all_objects
                                where rownum <=
                                      (select length(t.yqdlx) -
                                              length(replace(t.yqdlx, ',', '')) + 1
                                         from TRYINFO0 t
                                        where t.id = cr.id)) t2

                        where t1.id = cr.id),
                      TRYINFO0 t3
                where t3.id = cr.id) res
         left join knowledge k
           on res.text = k.name);
  end loop;
end;


/

