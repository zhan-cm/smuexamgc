create view SMU_COURSE_SOURCE as
select "CID","CNAME","SONAME"
    from kaoyi.course_source


/

