create view SMU_ANSWER_DB as
select "ID","CONTENT","QID"
    from kaoyi.answer_db


/

