create Procedure       insert_course_questiontype as
begin
  for cr in (select t.id from TRYINFO0 t) loop
    insert into course_questiontype
      (cid, qtid, qtname, qtorder)
      (select res.id, qt.id, res.text, qt.qorder
         from (select trim(substr(text,
                                  instr(text, ',', 1, rn) + 1,
                                  instr(text, ',', 1, rn + 1) -
                                  instr(text, ',', 1, rn) - 1)) text,
                      t3.id
                 from (select ',' || t1.tmlx || ',' text, t2.rn
                         from TRYINFO0 t1,
                              (select rownum rn
                                 from all_objects
                                where rownum <=
                                      (select length(t.tmlx) -
                                              length(replace(t.tmlx, ',', '')) + 1
                                         from TRYINFO0 t
                                        where t.id = cr.id)) t2

                        where t1.id = cr.id),
                      TRYINFO0 t3
                where t3.id = cr.id) res
        inner join questiontype qt
           on qt.name = res.text
          and qt.cid = res.id);
  end loop;
end;


/

