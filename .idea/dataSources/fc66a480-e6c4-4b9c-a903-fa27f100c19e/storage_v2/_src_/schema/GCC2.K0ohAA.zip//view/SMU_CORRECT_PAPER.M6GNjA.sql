create view SMU_CORRECT_PAPER as
select "ID","NAME"
    from kaoyi.correct_paper


/

