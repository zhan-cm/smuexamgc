create Procedure       insert_teacher_question as
begin
  for cr in (select t.id from kslx0 t where t.kslxxh = 0) loop
    insert into teacher_question
      (tid, eid, qid)
      select te.id, ei.id, eq.qid
        from teacher te,
             examinfo ei,
             exampaper_question eq,
             (select trim(substr(text,
                                 instr(text, ',', 1, rn) + 1,
                                 instr(text, ',', 1, rn + 1) -
                                 instr(text, ',', 1, rn) - 1)) pgst,
                     saname,
                     rn,
                     id2
                from (select ',' || t1.pgst || ',' text,
                             t2.rn,
                             t1.saname,
                             t1.id2
                        from KSLX0 t1,
                             (select rownum rn
                                from all_objects
                               where rownum <=
                                     (select length(t.pgst) -
                                             length(replace(t.pgst, ',', ''))
                                        from KSLX0 t
                                       where t.id = cr.id)) t2
                       where t1.id = cr.id)) res
       where res.saname = te.name
         and ei.num = res.id2
         and res.pgst = eq.qorder
         and ei.id = eq.eid;
  end loop;
end;


/

