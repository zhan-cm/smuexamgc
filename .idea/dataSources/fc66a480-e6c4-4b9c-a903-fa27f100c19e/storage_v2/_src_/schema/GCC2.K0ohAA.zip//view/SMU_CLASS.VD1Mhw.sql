create view SMU_CLASS as
select "ID","NAME"
    from kaoyi.class


/

