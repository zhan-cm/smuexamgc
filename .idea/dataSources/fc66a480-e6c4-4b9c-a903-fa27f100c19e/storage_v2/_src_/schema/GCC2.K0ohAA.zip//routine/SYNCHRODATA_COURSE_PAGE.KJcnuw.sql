create procedure synchrodata_course_page as
  pCount  number := 0;
  pCount2 number := 0;
begin
  for cr in (select distinct (ec.cid) as cid
               from exampaper_course ec, examinfo e
              where e.state != -1
                and ec.eid = e.id) loop
    select count(cid)
      into pCount
      from course_ques_page_total
     where cid = cr.cid;
    select count(p.id)
      into pCount2
      from examinfo p,exampaper_course ec2
     where p.state != -1
     and p.id=ec2.eid
       and ec2.cid = cr.cid;
    if (pCount = 0) then
      begin
        insert into course_ques_page_total
          (id, cid, page_total)
          select ctotal001_seq.nextval, cr.cid, pCount2 from dual;
        commit;
      end;
    else
      begin
        update course_ques_page_total
           set page_total = pCount2
         where cid = cr.cid;
        commit;
      end;
    end if;
  end loop;
end synchrodata_course_page;


/

