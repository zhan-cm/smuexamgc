create Procedure       insert_course_source as
begin
  for cr in (select t.id from TRYINFO0 t) loop
    insert into course_source
      (cid, soid, soname, soorder)
      (select res.id, so.id, res.text, so.sorder
         from (select trim(substr(text,
                                  instr(text, ',', 1, rn) + 1,
                                  instr(text, ',', 1, rn + 1) -
                                  instr(text, ',', 1, rn) - 1)) text,
                      t3.id
                 from (select ',' || t1.tylx || ',' text, t2.rn
                         from TRYINFO0 t1,
                              (select rownum rn
                                 from all_objects
                                where rownum <=
                                      (select length(t.tylx) -
                                              length(replace(t.tylx, ',', '')) + 1
                                         from TRYINFO0 t
                                        where t.id = cr.id)) t2

                        where t1.id = cr.id),
                      TRYINFO0 t3
                where t3.id = cr.id) res
         left join source so
           on res.text = so.name);
  end loop;
end;


/

