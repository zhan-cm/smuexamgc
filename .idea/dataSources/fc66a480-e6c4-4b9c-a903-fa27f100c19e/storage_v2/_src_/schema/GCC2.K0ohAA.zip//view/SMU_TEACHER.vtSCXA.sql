create view SMU_TEACHER as
select "ID","NAME","EMPLOYEE_NUM","STATE","LOGINTIME","UNITID","DEPID","ROLEID"
    from kaoyi.teacher


/

