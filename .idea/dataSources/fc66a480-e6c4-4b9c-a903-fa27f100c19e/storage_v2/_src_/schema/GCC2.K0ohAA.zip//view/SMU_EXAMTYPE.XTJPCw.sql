create view SMU_EXAMTYPE as
select "ID","NAME","STATE"
    from kaoyi.examtype


/

