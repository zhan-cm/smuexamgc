create PROCEDURE "SYN_DIRECTOR_PERMISSIONZJ01" as
begin
  for ea in (select id, cid
               from examinfo
              where state = 6
                and unitid = '23') loop

    insert into teacher_paper
      select t.id, ea.id, '31'
        from teacher t
       where id = 'c860626dd83347409359bdb781dcdd42';

  insert into teacher_paper
      select t.id, ea.id, '37'
        from teacher t
       where id = 'c860626dd83347409359bdb781dcdd42';

 --   insert into teacher_permission
 --     select t.id, ea.cid, '11', ''
  --      from teacher t
  ---     where id = 'c860626dd83347409359bdb781dcdd42';

  end loop;
  commit;
end SYN_DIRECTOR_PERMISSIONZJ01;


/

