create view SMU_STUDENT as
select "ID","NAME","CLASSID","SPECIALTYID","GRADE","STATE","LOGINTIME","NUM"
    from kaoyi.student


/

