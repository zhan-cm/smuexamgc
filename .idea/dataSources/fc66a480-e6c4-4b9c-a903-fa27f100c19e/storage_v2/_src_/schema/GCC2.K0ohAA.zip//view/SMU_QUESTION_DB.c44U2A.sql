create view SMU_QUESTION_DB as
select "ID","CID","ISMAIN","STATE","ANSWERID","DIFFICULTYID","KNOWLEDGEID","SOURCEID","COGNITIONID"
    from kaoyi.question_db


/

