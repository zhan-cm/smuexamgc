create view SMU_COURSE_EXAMTYPE as
select "CID","CNAME","ETNAME"
    from kaoyi.course_examtype


/

