create view SMU_COURSE_QUESTIONTYPE as
select "CID","CNAME","QTID","QTNAME","QTDESC","STATE"
    from kaoyi.course_questiontype


/

