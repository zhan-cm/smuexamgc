create view SMU_STUDENT_EXAM as
select "EID","SNUM"，"STATE","BEGINDATE","ENDDATE","COUNT","ENUM"
    from kaoyi.student_exam


/

