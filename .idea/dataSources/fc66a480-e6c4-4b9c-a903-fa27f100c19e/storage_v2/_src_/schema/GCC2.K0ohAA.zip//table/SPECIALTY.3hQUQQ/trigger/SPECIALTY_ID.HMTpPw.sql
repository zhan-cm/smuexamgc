create trigger SPECIALTY_ID
    before insert
    on SPECIALTY
    for each row
    when (new.id is null)
begin
select sp01_SEQ.nextval into:new.id from dual;
end;

/

