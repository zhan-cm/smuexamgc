create view SMU_GRADE as
select "ID","NAME"
    from kaoyi.grade


/

