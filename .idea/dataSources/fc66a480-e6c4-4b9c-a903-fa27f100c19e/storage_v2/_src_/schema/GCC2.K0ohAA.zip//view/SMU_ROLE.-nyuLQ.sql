create view SMU_ROLE as
select "ID","NAME","CNAME"
    from kaoyi.role


/

