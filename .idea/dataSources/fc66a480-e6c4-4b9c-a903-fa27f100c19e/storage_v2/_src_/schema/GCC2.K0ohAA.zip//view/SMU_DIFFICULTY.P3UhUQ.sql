create view SMU_DIFFICULTY as
select "ID","NAME"
    from kaoyi.difficulty


/

